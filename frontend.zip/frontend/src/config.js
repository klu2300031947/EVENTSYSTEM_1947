const config = 
{
    "url":"http://localhost:2025"
}

export default config